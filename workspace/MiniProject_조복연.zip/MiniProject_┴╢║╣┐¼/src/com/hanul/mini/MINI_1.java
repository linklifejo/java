package com.hanul.mini;

public class MINI_1 {

	public static void main(String[] args) {
		int a = 5; int b = 6;
		if (a > b) {
			System.out.printf("%d 와 %d중에 큰값은 %d 입니다.",a,b,a);
		}
		else {
			System.out.printf("%d 와 %d중에 큰값은 %d 입니다.",a,b,b);
			
		}
	}

}
